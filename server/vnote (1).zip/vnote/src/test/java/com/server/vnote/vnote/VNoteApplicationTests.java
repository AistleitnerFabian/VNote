package com.server.vnote.vnote;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VNoteApplicationTests {

	@Test
	void contextLoads() {
	}

}
